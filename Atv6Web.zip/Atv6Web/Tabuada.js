const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('Digite um número entre 1 e 10: ', (numero) => {
  numero = parseInt(numero);

  if (numero >= 1 && numero <= 10) {
    console.log(`Tabuada de ${numero}:`);

    for (let i = 1; i <= 10; i++) {
      console.log(`${numero} X ${i} = ${numero * i}`);
    }
  } else {
    console.log('Número inválido. Por favor, digite um número entre 1 e 10.');
  }

  rl.close();
});
