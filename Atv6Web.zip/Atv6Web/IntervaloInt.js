const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function obterNumeros() {
  return new Promise((resolve, reject) => {
    rl.question('Digite o primeiro número: ', (primeiroNumero) => {
      rl.question('Digite o segundo número: ', (segundoNumero) => {
        resolve([parseInt(primeiroNumero), parseInt(segundoNumero)]);
      });
    });
  });
}

async function main() {
  const [primeiroNumero, segundoNumero] = await obterNumeros();

  if (primeiroNumero <= segundoNumero) {
    for (let i = primeiroNumero; i <= segundoNumero; i++) {
      console.log(i);
    }
  } else {
    for (let i = primeiroNumero; i >= segundoNumero; i--) {
      console.log(i);
    }
  }

  rl.close();
}

main();
