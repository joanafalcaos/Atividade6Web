const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

let numeros = [];

function obterNumero() {
  return new Promise((resolve, reject) => {
    rl.question('Digite um número: ', (numero) => {
      resolve(numero);
    });
  });
}

async function main() {
  for (let i = 0; i < 5; i++) {
    const numero = await obterNumero();
    numeros.push(parseFloat(numero));
  }

  const maiorNumero = Math.max(...numeros);
  console.log("O maior número é:", maiorNumero);

  rl.close();
}

main();
