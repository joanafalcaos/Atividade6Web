const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function obterNumeros() {
  return new Promise((resolve, reject) => {
    rl.question('Digite o primeiro número: ', (primeiroNumero) => {
      rl.question('Digite o segundo número: ', (segundoNumero) => {
        resolve([parseInt(primeiroNumero), parseInt(segundoNumero)]);
      });
    });
  });
}

async function main() {
  const [primeiroNumero, segundoNumero] = await obterNumeros();
  let soma = 0;

  if (primeiroNumero <= segundoNumero) {
    for (let i = primeiroNumero; i <= segundoNumero; i++) {
      console.log(i);
      soma += i;
    }
  } else {
    for (let i = primeiroNumero; i >= segundoNumero; i--) {
      console.log(i);
      soma += i;
    }
  }

  console.log("A soma dos números é:", soma);

  rl.close();
}

main();
