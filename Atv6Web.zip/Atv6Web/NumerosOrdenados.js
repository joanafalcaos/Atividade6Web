for (let i = 1; i <= 20; i++) {
    console.log(i);
  }

 // Um ao lado do outro

 let numeros = "";

for (let i = 1; i <= 20; i++) {
  numeros += i + " ";
}

console.log(numeros);
 