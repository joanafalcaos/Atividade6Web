const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function calcularAnos(populacaoA, taxaCrescimentoA, populacaoB, taxaCrescimentoB) {
  let anos = 0;

  while (populacaoA < populacaoB) {
    populacaoA *= (1 + taxaCrescimentoA);
    populacaoB *= (1 + taxaCrescimentoB);
    anos++;
  }

  return anos;
}

function validarNumero(valor) {
  return !isNaN(valor) && valor > 0;
}

function validarTaxa(valor) {
  return !isNaN(valor) && valor >= 0 && valor <= 100; // Assume que as taxas estão em porcentagem
}

function obterEntrada(pergunta) {
  return new Promise((resolve, reject) => {
    rl.question(pergunta, (resposta) => {
      resolve(resposta);
    });
  });
}

async function main() {
  let repetir = true;

  while (repetir) {
    console.log("Digite as informações para os países:");

    let populacaoA, taxaCrescimentoA, populacaoB, taxaCrescimentoB;

    do {
      populacaoA = await obterEntrada("População do país A: ");
    } while (!validarNumero(populacaoA));

    do {
      taxaCrescimentoA = await obterEntrada("Taxa de crescimento do país A (em %): ");
    } while (!validarTaxa(taxaCrescimentoA));

    do {
      populacaoB = await obterEntrada("População do país B: ");
    } while (!validarNumero(populacaoB));

    do {
      taxaCrescimentoB = await obterEntrada("Taxa de crescimento do país B (em %): ");
    } while (!validarTaxa(taxaCrescimentoB));

    const anosNecessarios = calcularAnos(parseFloat(populacaoA), parseFloat(taxaCrescimentoA) / 100, parseFloat(populacaoB), parseFloat(taxaCrescimentoB) / 100);
    console.log("Número de anos necessários:", anosNecessarios);

    const respostaRepetir = await obterEntrada("Deseja repetir a operação? (sim/não): ");
    repetir = respostaRepetir.toLowerCase() === 'sim';
  }

  rl.close();
}

main();
